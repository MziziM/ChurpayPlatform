import { useState } from "react";
import { Header } from "./components/Header";
import { SuperAdminHeader } from "./components/SuperAdminHeader";
import { Dashboard } from "./components/Dashboard";
import { Donations } from "./components/Donations";
import { Members } from "./components/Members";
import { Campaigns } from "./components/Campaigns";
import { Reports } from "./components/Reports";
import { SuperAdminOverview } from "./components/SuperAdminOverview";
import { ChurchManagement } from "./components/ChurchManagement";
import { FinancialOverview } from "./components/FinancialOverview";
import { Button } from "./components/ui/button";
import { Badge } from "./components/ui/badge";
import { Shield, Building2 } from "lucide-react";

export default function App() {
  const [currentView, setCurrentView] = useState("dashboard");
  const [isSuperAdminMode, setIsSuperAdminMode] = useState(false);

  // Reset view when switching modes
  const toggleAdminMode = () => {
    setIsSuperAdminMode(!isSuperAdminMode);
    setCurrentView(isSuperAdminMode ? "dashboard" : "overview");
  };

  const renderChurchAdminView = () => {
    switch (currentView) {
      case "dashboard":
        return <Dashboard />;
      case "donations":
        return <Donations />;
      case "members":
        return <Members />;
      case "campaigns":
        return <Campaigns />;
      case "reports":
        return <Reports />;
      default:
        return <Dashboard />;
    }
  };

  const renderSuperAdminView = () => {
    switch (currentView) {
      case "overview":
        return <SuperAdminOverview />;
      case "churches":
        return <ChurchManagement />;
      case "finances":
        return <FinancialOverview />;
      case "users":
        return <div className="p-6"><h1>User Management - Coming Soon</h1></div>;
      case "support":
        return <div className="p-6"><h1>Support Center - Coming Soon</h1></div>;
      case "analytics":
        return <div className="p-6"><h1>Platform Analytics - Coming Soon</h1></div>;
      case "system":
        return <div className="p-6"><h1>System Management - Coming Soon</h1></div>;
      default:
        return <SuperAdminOverview />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Admin Mode Toggle */}
      <div className="bg-slate-800 px-6 py-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="text-white text-sm">
              Current Mode: 
              <Badge className={`ml-2 ${isSuperAdminMode ? 'bg-red-600 text-white' : 'bg-blue-600 text-white'}`}>
                {isSuperAdminMode ? 'Super Admin' : 'Church Admin'}
              </Badge>
            </div>
            {isSuperAdminMode && (
              <div className="text-slate-300 text-xs">
                Platform-wide access enabled
              </div>
            )}
          </div>
          <Button 
            onClick={toggleAdminMode}
            variant="outline" 
            size="sm"
            className="border-slate-600 text-slate-300 hover:bg-slate-700 hover:text-white"
          >
            {isSuperAdminMode ? (
              <>
                <Building2 className="h-4 w-4 mr-2" />
                Switch to Church Admin
              </>
            ) : (
              <>
                <Shield className="h-4 w-4 mr-2" />
                Switch to Super Admin
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Header */}
      {isSuperAdminMode ? (
        <SuperAdminHeader currentView={currentView} onViewChange={setCurrentView} />
      ) : (
        <Header currentView={currentView} onViewChange={setCurrentView} />
      )}

      {/* Main Content */}
      <main className="flex-1">
        {isSuperAdminMode ? renderSuperAdminView() : renderChurchAdminView()}
      </main>
    </div>
  );
}